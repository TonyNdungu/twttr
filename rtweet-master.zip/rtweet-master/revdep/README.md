# Platform

|field    |value                        |
|:--------|:----------------------------|
|version  |R version 3.5.1 (2018-07-02) |
|os       |macOS High Sierra 10.13.6    |
|system   |x86_64, darwin15.6.0         |
|ui       |RStudio                      |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|ctype    |en_US.UTF-8                  |
|tz       |America/Chicago              |
|date     |2018-09-28                   |

# Dependencies

|package |old   |new |Δ  |
|:-------|:-----|:---|:--|
|rtweet  |0.6.7 |NA  |*  |

# Revdeps

## All (1)

|package                                |version |error |warning |note |
|:--------------------------------------|:-------|:-----|:-------|:----|
|[graphTweets](problems.md#graphtweets) |0.5.0   |      |        |1    |

