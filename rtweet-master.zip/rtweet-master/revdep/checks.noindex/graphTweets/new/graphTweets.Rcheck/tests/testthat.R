library(testthat)
library(graphTweets)

test_check("graphTweets")
